package com.policymanagement.premiummanagement.dtos;
 
import lombok.Data;
 
@Data
public class PolicyTypesDTO {
    private int policyId;
    private String policyName;   
}