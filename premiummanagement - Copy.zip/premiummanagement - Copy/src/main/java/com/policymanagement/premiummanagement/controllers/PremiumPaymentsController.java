package com.policymanagement.premiummanagement.controllers;

import java.time.LocalDate;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.policymanagement.premiummanagement.dtos.PolicyDto;
import com.policymanagement.premiummanagement.dtos.PremiumPaymentDto;
import com.policymanagement.premiummanagement.services.PremiumPaymentsService;
import com.policymanagement.premiummanagement.services.PremiumsMasterService;

@RestController
@RequestMapping("/api/premium")
public class PremiumPaymentsController {
    @Autowired
    private PremiumPaymentsService service;
    
    @Autowired
    private PremiumsMasterService premiumsMasterService;

    @PostMapping
    public ResponseEntity<PremiumPaymentDto> addPremiumPayment(@RequestBody PremiumPaymentDto dto) {
        PremiumPaymentDto result = service.addPremiumPayment(dto);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @GetMapping("/{username}/{subscriptionId}/history")
    public ResponseEntity<List<PremiumPaymentDto>> getPremiumPaymentsForSubscription(
            @PathVariable String username, @PathVariable int subscriptionId) {
        List<PremiumPaymentDto> paymentHistory = service.getPremiumPaymentsForSubscription(username, subscriptionId);
        return new ResponseEntity<>(paymentHistory, HttpStatus.OK);
    }

    @GetMapping("/calculatelatefee")
    public ResponseEntity<Float> calculateLateFee(
            @RequestParam("paymentDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate paymentDate,
            @RequestParam("premiumAmount") Float premiumAmount) {
        Float lateFee = service.calculateLateFee(paymentDate, premiumAmount);
        return ResponseEntity.ok(lateFee);
    }
    
    @GetMapping("/dues")
    public List<PolicyDto> getDuePolicies() {
    	return premiumsMasterService.getDueList();
    }
}
