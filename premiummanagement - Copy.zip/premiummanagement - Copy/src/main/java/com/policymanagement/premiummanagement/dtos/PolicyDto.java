package com.policymanagement.premiummanagement.dtos;

import java.time.LocalDate;

import com.policymanagement.premiummanagement.dtos.PolicyDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PolicyDto {
    private int policyId;
    private String username;
    private LocalDate premiumStartDate;
    private float premiumAmount;
    private String currentPolicyStatus;
}
