package com.policymanagement.premiummanagement.dtos;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PremiumMasterDto {
    private int id;
    private int policyId;
    private String username;
    private int subscriptionId;
    private LocalDate premiumStartDate;
    private Float premiumAmount;
    private int totalNumberOfPremiums;
    private String currentPolicyStatus;
    private LocalDate lastPaymentDate;
}