package com.policymanagement.premiummanagement.exception;

public class PolicyMaturedException extends RuntimeException {
    public PolicyMaturedException(String message) {
        super(message);
    }
}
