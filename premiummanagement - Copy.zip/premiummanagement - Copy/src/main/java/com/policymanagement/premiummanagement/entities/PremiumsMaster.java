package com.policymanagement.premiummanagement.entities;

import java.time.LocalDate;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class PremiumsMaster {
    @Id
    @Column(columnDefinition = "INT(10)")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull
    @Column(columnDefinition = "INT(10)")
    private int policyId;

    @NotNull
    @Column(length = 10)
    private String username;

    @NotNull
    @Column(columnDefinition = "INT(10)")
    private int subscriptionId;

    @NotNull
    private LocalDate premiumStartDate;

    @NotNull
    @Column(columnDefinition = "FLOAT(10)")
    private float premiumAmount;

    @NotNull
    @Column(columnDefinition = "INT(10)")
    private int totalNumberOfPremiums;

    @NotNull
    @Column(length = 20)
    private String currentPolicyStatus;

    private LocalDate lastPaymentDate;
}