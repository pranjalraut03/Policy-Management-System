package com.policymanagement.premiummanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policymanagement.premiummanagement.entities.PremiumPayments;
import com.policymanagement.premiummanagement.entities.PremiumsMaster;

@Repository
public interface PremiumPaymentRepository extends JpaRepository<PremiumPayments, Integer> {
	int countByPremiumMasterId(PremiumsMaster premiumMasterId);

	}
