//package com.policymanagement.premiummanagement;
//
//import java.util.Arrays;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import com.policymanagement.premiummanagement.entities.PaymentMethods;
//import com.policymanagement.premiummanagement.repos.PaymentMethodRepository;
//
//@Component
//public class DataLoader implements CommandLineRunner {
//
//    @Autowired
//    private PaymentMethodRepository paymentMethodsRepository;
//
//    
//    	public void run(String... args) throws Exception {
//    	    // Clear existing data
//    	    paymentMethodsRepository.deleteAll();
//
//    	    // Seed PaymentMethods
//    	    PaymentMethods card = new PaymentMethods(1,"Debit Card");
//    	    PaymentMethods card1 = new PaymentMethods(2,"Credit Card");
//    	    PaymentMethods netBanking = new PaymentMethods(3,"NetBanking");
//    	    PaymentMethods upi = new PaymentMethods(4,"UPI");
//    	    PaymentMethods cash = new PaymentMethods(5,"Cash");
//
//    	    // Save each payment method individually
//    	    paymentMethodsRepository.save(card);
//    	    paymentMethodsRepository.save(card1);
//    	    paymentMethodsRepository.save(netBanking);
//    	    paymentMethodsRepository.save(upi);
//    	    paymentMethodsRepository.save(cash);
//    	}
//    }
