package com.policymanagement.premiummanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policymanagement.premiummanagement.entities.PremiumsMaster;

@Repository
public interface PremiumMasterRepository extends JpaRepository<PremiumsMaster, Integer> {
   
}
