package com.policymanagement.premiummanagement.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class PaymentMethods {
	@Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(columnDefinition = "INT(10)")
    private int id;
	
	@Column(length = 20)
    private String paymentMethod;
    // getters and setters

}
