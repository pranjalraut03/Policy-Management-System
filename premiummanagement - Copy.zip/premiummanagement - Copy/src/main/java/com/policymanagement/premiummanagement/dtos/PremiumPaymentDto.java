package com.policymanagement.premiummanagement.dtos;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PremiumPaymentDto {
    private int id;
    private LocalDate paymentDate;
    private String bankTransactionId;
    private Float premiumAmount;
    private Float lateFee;
    private int premiumMasterId;
    private int paymentMethodId;
}
