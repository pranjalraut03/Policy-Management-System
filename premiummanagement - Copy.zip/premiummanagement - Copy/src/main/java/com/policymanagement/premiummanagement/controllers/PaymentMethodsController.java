package com.policymanagement.premiummanagement.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.policymanagement.premiummanagement.dtos.PaymentMethodDto;
import com.policymanagement.premiummanagement.services.PaymentMethodsService;

@RestController
@RequestMapping("/api/paymentmethods")
public class PaymentMethodsController {
    @Autowired
    private PaymentMethodsService service;

    @GetMapping
    public List<PaymentMethodDto> getAllPaymentMethods() {
        return service.getAllPaymentMethods();
    }
}
