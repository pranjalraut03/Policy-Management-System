package com.policymanagement.premiummanagement.services;

import java.util.List;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policymanagement.premiummanagement.dtos.PaymentMethodDto;
import com.policymanagement.premiummanagement.repos.PaymentMethodRepository;

@Service
public class PaymentMethodsService {
    @Autowired
    private PaymentMethodRepository repository;

    public List<PaymentMethodDto> getAllPaymentMethods() {
        return repository.findAll().stream().map(entity -> new PaymentMethodDto(entity.getId(), entity.getPaymentMethod())).collect(Collectors.toList());
    }
}
