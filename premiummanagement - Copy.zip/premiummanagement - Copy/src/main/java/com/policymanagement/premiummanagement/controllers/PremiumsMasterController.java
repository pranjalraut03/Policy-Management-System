package com.policymanagement.premiummanagement.controllers;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.policymanagement.premiummanagement.dtos.PremiumMasterDto;
import com.policymanagement.premiummanagement.services.PremiumsMasterService;

@RestController
@RequestMapping("/api/premiumsmaster")
public class PremiumsMasterController {
    @Autowired
    private PremiumsMasterService service;

    @PostMapping
    public PremiumMasterDto addPremiumMaster(@RequestBody PremiumMasterDto dto) {
        return service.addPremiumMaster(dto);
    }
    
    @GetMapping
    public List<PremiumMasterDto> getAllPremiumMasters() {
        return service.getAllPremiumMasters();
    }

    @GetMapping("/{id}")
    public Optional<PremiumMasterDto> getPremiumMasterById(@PathVariable int id) {
        return service.getPremiumMasterById(id);
    }

//    @PutMapping("/{id}/status")
//    public PremiumMasterDto updatePolicyStatus(@PathVariable int id, @RequestParam String status) {
//        return service.updatePolicyStatus(id, status);
//    }
}