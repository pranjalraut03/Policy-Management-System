package com.policymanagement.premiummanagement.dtos;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DuePaymentDto {
    private Long id;
    private LocalDate paymentDate;
    private String bankTransactionId;
    private BigDecimal premiumAmount;
    private BigDecimal lateFee;
}
