package com.policymanagement.premiummanagement.services;


import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import com.policymanagement.premiummanagement.entities.PremiumsMaster;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policymanagement.premiummanagement.dtos.PremiumPaymentDto;
import com.policymanagement.premiummanagement.entities.PremiumPayments;
import com.policymanagement.premiummanagement.exception.PolicyMaturedException;
import com.policymanagement.premiummanagement.repos.PaymentMethodRepository;
import com.policymanagement.premiummanagement.repos.PremiumMasterRepository;
import com.policymanagement.premiummanagement.repos.PremiumPaymentRepository;

@Service
public class PremiumPaymentsService {
    @Autowired
    private PremiumPaymentRepository repository;
    @Autowired
    private PremiumMasterRepository premiumsMasterRepository;
    @Autowired
    private PaymentMethodRepository paymentMethodsRepository;

    public PremiumPaymentDto addPremiumPayment(PremiumPaymentDto dto) {
        PremiumPayments payment = new PremiumPayments();
        PremiumsMaster premiumMaster = premiumsMasterRepository.findById(dto.getPremiumMasterId()).orElse(null);
        if (premiumMaster == null) {
            throw new IllegalArgumentException("Invalid premium master ID");
        }

        
        LocalDate paymentDate = dto.getPaymentDate() != null ? dto.getPaymentDate() : LocalDate.now();
        if (paymentDate.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Payment date cannot be in the future.");
        }       
        // Check if a payment has already been made in the same month
        if (premiumMaster.getLastPaymentDate() != null && 
            paymentDate.getMonth() == premiumMaster.getLastPaymentDate().getMonth() &&
            paymentDate.getYear() == premiumMaster.getLastPaymentDate().getYear()) {
            throw new IllegalArgumentException("Payment should be made once every month.");
        }
        payment.setPaymentDate(paymentDate);

        
        payment.setBankTransactionId(dto.getBankTransactionId());
      
     // Validate the premium amount
        if (dto.getPremiumAmount() != premiumMaster.getPremiumAmount()) {
            throw new IllegalArgumentException("Premium amount does not match the expected amount.");
        }
        payment.setPremiumAmount(dto.getPremiumAmount());
        
        float lateFee = calculateLateFee(dto.getPaymentDate(), dto.getPremiumAmount());
        if(dto.getLateFee()!=lateFee) {
        	throw new IllegalArgumentException("Late fee does not match the excepted late fee.");
        }
        payment.setLateFee(dto.getLateFee());
        

        payment.setPremiumMasterId(premiumsMasterRepository.findById(dto.getPremiumMasterId()).orElse(null));
        payment.setPaymentMethodId(paymentMethodsRepository.findById(dto.getPaymentMethodId()).orElse(null));

        // Business rule: Check if total number of premium payments exceeds the allowed number
        int count = repository.countByPremiumMasterId(payment.getPremiumMasterId());
        if (count >= payment.getPremiumMasterId().getTotalNumberOfPremiums()) {
            throw new PolicyMaturedException("Total number of premium payments exceeded for this policy.");
        }
        repository.save(payment);
        
     // Update policy status to "Matured" if all premiums are completed
        if (count + 1 == payment.getPremiumMasterId().getTotalNumberOfPremiums()) {
            payment.getPremiumMasterId().setCurrentPolicyStatus("Matured");
            premiumsMasterRepository.save(payment.getPremiumMasterId());
        }
        // Update the last payment date in PremiumsMaster
        premiumMaster.setLastPaymentDate(paymentDate);
        premiumsMasterRepository.save(premiumMaster);

        return dto;
    }

    public List<PremiumPaymentDto> getPremiumPaymentsForSubscription(String username, int subscriptionId) {
        return repository.findAll().stream()
            .filter(payment -> payment.getPremiumMasterId().getSubscriptionId()==subscriptionId && payment.getPremiumMasterId().getUsername().equals(username))
            .map(payment -> new PremiumPaymentDto(payment.getId(), payment.getPaymentDate(), payment.getBankTransactionId(), payment.getPremiumAmount(), payment.getLateFee(), payment.getPremiumMasterId().getId(), payment.getPaymentMethodId().getId()))
            .collect(Collectors.toList());
    }
    
    public Float calculateLateFee(LocalDate paymentDate, Float premiumAmount) {
        if (paymentDate != null && paymentDate.isAfter(LocalDate.now().withDayOfMonth(5))) {
        	long daysLate = ChronoUnit.DAYS.between(LocalDate.now().withDayOfMonth(5), paymentDate);
            float lateFeeRate = 0.00025f;
            return premiumAmount * lateFeeRate * daysLate;
        }
        return 0.0f;
    }
}
