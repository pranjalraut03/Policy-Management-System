package com.policymanagement.premiummanagement.services;

import java.sql.Date;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policymanagement.premiummanagement.dtos.PolicyDto;
import com.policymanagement.premiummanagement.dtos.PremiumMasterDto;
import com.policymanagement.premiummanagement.entities.PremiumsMaster;
import com.policymanagement.premiummanagement.repos.PremiumMasterRepository;

@Service
public class PremiumsMasterService {
	@Autowired
	private PremiumMasterRepository repository;

	@Autowired
	private PremiumMasterRepository premiumMasterRepository;

	public PremiumMasterDto addPremiumMaster(PremiumMasterDto dto) {
		validatePremiumMasterDto(dto);
		PremiumsMaster entity = new PremiumsMaster(dto.getId(), dto.getPolicyId(), dto.getUsername(),
				dto.getSubscriptionId(), dto.getPremiumStartDate(), dto.getPremiumAmount(),
				dto.getTotalNumberOfPremiums(), dto.getCurrentPolicyStatus(), dto.getLastPaymentDate());
		repository.save(entity);
		return dto;
	}

	public List<PremiumMasterDto> getAllPremiumMasters() {
		return repository.findAll().stream()
				.map(entity -> new PremiumMasterDto(entity.getId(), entity.getPolicyId(), entity.getUsername(),
						entity.getSubscriptionId(), entity.getPremiumStartDate(), entity.getPremiumAmount(), entity.getTotalNumberOfPremiums(),
						entity.getCurrentPolicyStatus(), entity.getLastPaymentDate()))
				.collect(Collectors.toList());
	}

	public Optional<PremiumMasterDto> getPremiumMasterById(int id) {
		return repository.findById(id)
				.map(entity -> new PremiumMasterDto(entity.getId(), entity.getPolicyId(), entity.getUsername(),
						entity.getSubscriptionId(), entity.getPremiumStartDate(), entity.getPremiumAmount(), entity.getTotalNumberOfPremiums(),
						entity.getCurrentPolicyStatus(), entity.getLastPaymentDate()));
	}

	private void validatePremiumMasterDto(PremiumMasterDto dto) {
		if (dto.getUsername().length() != 10) {
			throw new IllegalArgumentException("Username must be exactly 10 characters long");
		}
		if (!dto.getCurrentPolicyStatus().matches("Ongoing|Matured|Defaulted|Cancelled")) {
			throw new IllegalArgumentException(
					"Allowed values for current policy status are - Ongoing, Matured, Defaulted, Cancelled");
		}
		if (dto.getPremiumStartDate().isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Premium start date should not be a past date");
		}
		if (dto.getLastPaymentDate() != null && dto.getLastPaymentDate().isBefore(dto.getPremiumStartDate())) {
			throw new IllegalArgumentException("Last payment date should not be earlier than the premium start date");
		}
	}


	public List<PolicyDto> getDueList() {
		List<PolicyDto> duePolicies = new ArrayList<PolicyDto>();
		premiumMasterRepository.findAll().stream().filter((premium) -> {
			return (premium.getLastPaymentDate().getMonthValue() < Date.valueOf(LocalDate.now()).getMonth()
					&& premium.getLastPaymentDate().getYear() <= LocalDate.now().getYear()
					&& LocalDate.now().getYear() >= 5
					|| premium.getLastPaymentDate().getYear() < LocalDate.now().getYear())
					&& premium.getCurrentPolicyStatus().equalsIgnoreCase("Ongoing");
		}).forEach(policy -> {
			duePolicies.add(new PolicyDto(policy.getPolicyId(), policy.getUsername(), policy.getPremiumStartDate(),
					policy.getPremiumAmount(), policy.getCurrentPolicyStatus()));
		});

		return duePolicies;
	}
}