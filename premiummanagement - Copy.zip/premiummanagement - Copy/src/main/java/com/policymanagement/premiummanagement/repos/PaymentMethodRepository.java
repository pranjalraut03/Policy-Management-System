package com.policymanagement.premiummanagement.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.policymanagement.premiummanagement.entities.PaymentMethods;

@Repository
public interface PaymentMethodRepository extends JpaRepository<PaymentMethods, Integer> {

}