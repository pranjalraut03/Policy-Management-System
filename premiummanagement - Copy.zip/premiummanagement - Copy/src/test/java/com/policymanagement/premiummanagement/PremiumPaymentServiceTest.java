package com.policymanagement.premiummanagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.policymanagement.premiummanagement.dtos.PremiumPaymentDto;
import com.policymanagement.premiummanagement.entities.PaymentMethods;
import com.policymanagement.premiummanagement.entities.PremiumPayments;
import com.policymanagement.premiummanagement.entities.PremiumsMaster;
import com.policymanagement.premiummanagement.exception.PolicyMaturedException;
import com.policymanagement.premiummanagement.repos.PaymentMethodRepository;
import com.policymanagement.premiummanagement.repos.PremiumMasterRepository;
import com.policymanagement.premiummanagement.repos.PremiumPaymentRepository;
import com.policymanagement.premiummanagement.services.PremiumPaymentsService;

@ExtendWith(MockitoExtension.class)
public class PremiumPaymentServiceTest {

    @Mock
    private PremiumPaymentRepository repository;

    @Mock
    private PremiumMasterRepository premiumsMasterRepository;

    @Mock
    private PaymentMethodRepository paymentMethodsRepository;

    @InjectMocks
    private PremiumPaymentsService service;

    private PremiumPaymentDto premiumPaymentDto;
    private PremiumsMaster premiumsMaster;
    private PaymentMethods paymentMethods;

    @BeforeEach
    void setUp() {
        premiumPaymentDto = new PremiumPaymentDto(1, LocalDate.now().withDayOfMonth(10), "TXN123", 1000.0f, 1.25f, 1, 1);
        premiumsMaster = new PremiumsMaster(1, 101, "username123", 123, LocalDate.now().plusDays(1), 1000.0f, 12, "Ongoing", null);
        paymentMethods= new PaymentMethods(1,"UPI");
    }

    @Test
    void addPremiumPayment_ShouldSaveAndReturnDto() {
        when(premiumsMasterRepository.findById(1)).thenReturn(Optional.of(premiumsMaster));
        when(repository.countByPremiumMasterId(premiumsMaster)).thenReturn(0);

        PremiumPaymentDto result = service.addPremiumPayment(premiumPaymentDto);

        assertEquals(premiumPaymentDto, result);
        verify(repository, times(1)).save(any(PremiumPayments.class));
    }

    @Test
    void addPremiumPayment_ShouldThrowPolicyMaturedException_WhenPaymentsExceedTotal() {
        when(premiumsMasterRepository.findById(1)).thenReturn(Optional.of(premiumsMaster));
        when(repository.countByPremiumMasterId(premiumsMaster)).thenReturn(12);

        assertThrows(PolicyMaturedException.class, () -> {
            service.addPremiumPayment(premiumPaymentDto);
        });
    }

    @Test
    void addPremiumPayment_ShouldThrowIllegalArgumentException_WhenPaymentDateIsFuture() {
        premiumPaymentDto.setPaymentDate(LocalDate.now().plusDays(1));

        assertThrows(IllegalArgumentException.class, () -> {
            service.addPremiumPayment(premiumPaymentDto);
        });
    }

    @Test
    void addPremiumPayment_ShouldThrowIllegalArgumentException_WhenPremiumAmountDoesNotMatch() {
        premiumPaymentDto.setPremiumAmount(2000.0f);
        when(premiumsMasterRepository.findById(1)).thenReturn(Optional.of(premiumsMaster));

        assertThrows(IllegalArgumentException.class, () -> {
            service.addPremiumPayment(premiumPaymentDto);
        });
    }

    @Test
    void addPremiumPayment_ShouldThrowIllegalArgumentException_WhenLateFeeDoesNotMatch() {
        premiumPaymentDto.setLateFee(3.0f);
        when(premiumsMasterRepository.findById(1)).thenReturn(Optional.of(premiumsMaster));

        assertThrows(IllegalArgumentException.class, () -> {
            service.addPremiumPayment(premiumPaymentDto);
        });
    }

    @Test
    void getPremiumPaymentsForSubscription_ShouldReturnPayments() {
        PremiumPayments payment = new PremiumPayments();
        payment.setId(1);
        payment.setPaymentDate(LocalDate.now());
        payment.setBankTransactionId("TXN123");
        payment.setPremiumAmount(2000.0f);
        payment.setLateFee(0.00f);
        payment.setPremiumMasterId(premiumsMaster);
        payment.setPaymentMethodId(paymentMethods);

        when(repository.findAll()).thenReturn(Arrays.asList(payment));

        List<PremiumPaymentDto> result = service.getPremiumPaymentsForSubscription("username123", 123);

        assertEquals(1, result.size());
        assertEquals("TXN123", result.get(0).getBankTransactionId());
    }

    @Test
    void calculateLateFee_ShouldReturnCorrectLateFee_WhenPaymentDateIsAfter5th() {
        // Scenario: Payment date is after the 5th of the month
        LocalDate paymentDateAfter5th = LocalDate.now().withDayOfMonth(16);
        Float premiumAmount = 1000.0f;
        Float expectedLateFee = premiumAmount * 0.00025f * ChronoUnit.DAYS.between(LocalDate.now().withDayOfMonth(5), paymentDateAfter5th);

        Float lateFee = service.calculateLateFee(paymentDateAfter5th, premiumAmount);

        assertEquals(expectedLateFee, lateFee);
        
    }


    @Test
    void calculateLateFee_ShouldReturnZero_WhenPaymentDateIsBefore5th() {
    	LocalDate paymentDateOn5th = LocalDate.now().withDayOfMonth(5);
        LocalDate paymentDateBefore5th = LocalDate.now().withDayOfMonth(4);
        Float premiumAmount = 1000.0f;
        Float lateFee = service.calculateLateFee(paymentDateOn5th, premiumAmount);
        assertEquals(0.0f, lateFee);

        lateFee = service.calculateLateFee(paymentDateBefore5th, premiumAmount);
        assertEquals(0.0f, lateFee);
    }
    }
//}
