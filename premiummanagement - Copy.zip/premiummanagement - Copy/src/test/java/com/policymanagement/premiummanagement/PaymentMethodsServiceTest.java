package com.policymanagement.premiummanagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.policymanagement.premiummanagement.dtos.PaymentMethodDto;
import com.policymanagement.premiummanagement.entities.PaymentMethods;
import com.policymanagement.premiummanagement.repos.PaymentMethodRepository;
import com.policymanagement.premiummanagement.services.PaymentMethodsService;

@ExtendWith(MockitoExtension.class)
public class PaymentMethodsServiceTest {

    @Mock
    private PaymentMethodRepository repository;

    @InjectMocks
    private PaymentMethodsService service;

    private List<PaymentMethods> paymentMethods;

    @BeforeEach
    void setUp() {
        paymentMethods = Arrays.asList(
            new PaymentMethods(1, "Card"),
            new PaymentMethods(2, "NetBanking"),
            new PaymentMethods(3, "UPI")
        );
    }

    @Test
    void getAllPaymentMethods_ShouldReturnAllPaymentMethods() {
        when(repository.findAll()).thenReturn(paymentMethods);

        List<PaymentMethodDto> result = service.getAllPaymentMethods();

        assertEquals(3, result.size());
        assertEquals("Card", result.get(0).getPaymentMethod());
        assertEquals("UPI", result.get(2).getPaymentMethod());
        assertEquals("NetBanking", result.get(1).getPaymentMethod());
    }
}
