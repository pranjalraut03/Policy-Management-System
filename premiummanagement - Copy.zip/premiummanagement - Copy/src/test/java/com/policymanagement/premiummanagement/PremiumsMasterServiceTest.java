package com.policymanagement.premiummanagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.policymanagement.premiummanagement.dtos.PremiumMasterDto;
import com.policymanagement.premiummanagement.entities.PremiumsMaster;
import com.policymanagement.premiummanagement.repos.PremiumMasterRepository;
import com.policymanagement.premiummanagement.services.PremiumsMasterService;

@ExtendWith(MockitoExtension.class)
public class PremiumsMasterServiceTest {

    @Mock
    private PremiumMasterRepository repository;

    @InjectMocks
    private PremiumsMasterService service;

    private PremiumMasterDto premiumMasterDto;
    private PremiumsMaster premiumsMaster;

    @BeforeEach
    void setUp() {
        premiumMasterDto = new PremiumMasterDto(1, 101, "username123", 123, LocalDate.now().plusDays(1), 1000.00f, 12, "Ongoing", null);
        premiumsMaster = new PremiumsMaster(1, 101, "username123", 123, LocalDate.now().plusDays(1), 1000.00f, 12, "Ongoing", null);
    }

    @Test
    void addPremiumMaster_ShouldSaveAndReturnDto() {
        when(repository.save(any(PremiumsMaster.class))).thenReturn(premiumsMaster);

        PremiumMasterDto result = service.addPremiumMaster(premiumMasterDto);

        assertEquals(premiumMasterDto, result);
    }

    @Test
    void getAllPremiumMasters_ShouldReturnAllPremiumMasters() {
        when(repository.findAll()).thenReturn(Arrays.asList(premiumsMaster));

        List<PremiumMasterDto> result = service.getAllPremiumMasters();

        assertEquals(1, result.size());
        assertEquals(premiumMasterDto.getUsername(), result.get(0).getUsername());
    }

    @Test
    void getPremiumMasterById_ShouldReturnPremiumMaster() {
        when(repository.findById(1)).thenReturn(Optional.of(premiumsMaster));

        Optional<PremiumMasterDto> result = service.getPremiumMasterById(1);

        assertTrue(result.isPresent());
        assertEquals(premiumMasterDto.getUsername(), result.get().getUsername());
    }

    @Test
    void addPremiumMaster_ShouldThrowException_WhenUsernameIsInvalid() {
        premiumMasterDto.setUsername("short");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addPremiumMaster(premiumMasterDto);
        });

        assertEquals("Username must be exactly 10 characters long", exception.getMessage());
    }

    @Test
    void addPremiumMaster_ShouldThrowException_WhenPolicyStatusIsInvalid() {
        premiumMasterDto.setCurrentPolicyStatus("InvalidStatus");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addPremiumMaster(premiumMasterDto);
        });

        assertEquals("Allowed values for current policy status are - Ongoing, Matured, Defaulted, Cancelled", exception.getMessage());
    }

    @Test
    void addPremiumMaster_ShouldThrowException_WhenPremiumStartDateIsPast() {
        premiumMasterDto.setPremiumStartDate(LocalDate.now().minusDays(1));

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addPremiumMaster(premiumMasterDto);
        });

        assertEquals("Premium start date should not be a past date", exception.getMessage());
    }
}
