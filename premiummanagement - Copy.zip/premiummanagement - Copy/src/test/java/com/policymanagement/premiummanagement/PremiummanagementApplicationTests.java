package com.policymanagement.premiummanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PremiummanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
